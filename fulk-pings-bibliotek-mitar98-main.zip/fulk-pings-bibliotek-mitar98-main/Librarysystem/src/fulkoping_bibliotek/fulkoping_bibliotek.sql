-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Värd: mysql
-- Tid vid skapande: 24 jan 2025 kl 22:46
-- Serverversion: 8.0.41
-- PHP-version: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `fulkoping_bibliotek`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `books`
--

CREATE TABLE `books` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `material_type` enum('book','magazine','media') DEFAULT 'book',
  `is_borrowed` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumpning av Data i tabell `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `material_type`, `is_borrowed`) VALUES
(1, 'Harry Potter och de vises sten', 'J.K. Rowling', 'book', 1),
(2, 'Stolthet och fördom', 'Jane Austen', 'book', 1),
(3, 'Moby Dick', 'Herman Melville', 'book', 1),
(4, 'Brott och straff', 'Fyodor Dostoevsky', 'book', 0),
(5, 'Teknikmagasinet', 'Redaktionen', 'magazine', 1),
(6, 'Vetenskap och framtid', 'Redaktionen', 'magazine', 0),
(7, 'Den stora dokumentären', 'Filmteamet', 'media', 1),
(8, 'Framtiden och AI', 'Teknikkollektiv', 'media', 1);

-- --------------------------------------------------------

--
-- Tabellstruktur `loans`
--

CREATE TABLE `loans` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `book_id` int DEFAULT NULL,
  `borrow_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumpning av Data i tabell `loans`
--

INSERT INTO `loans` (`id`, `user_id`, `book_id`, `borrow_date`, `return_date`) VALUES
(1, 1, 1, '2025-01-15', NULL),
(2, 2, 3, '2025-01-10', NULL),
(3, 3, 2, '2025-01-24', '2025-02-23'),
(4, 3, 7, '2025-01-24', '2025-02-03');

-- --------------------------------------------------------

--
-- Tabellstruktur `reservations`
--

CREATE TABLE `reservations` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `book_id` int NOT NULL,
  `reservation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumpning av Data i tabell `reservations`
--

INSERT INTO `reservations` (`id`, `user_id`, `book_id`, `reservation_date`) VALUES
(1, 1, 2, '2025-01-20'),
(2, 2, 4, '2025-01-18');

-- --------------------------------------------------------

--
-- Tabellstruktur `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumpning av Data i tabell `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `email`, `name`, `phone_number`) VALUES
(1, 'oskar_nord', 'hashedpassword123', 'oskar.nord@example.com', 'Oskar Nord', '070-1234567'),
(2, 'julia_lind', 'hashedpassword456', 'julia.lind@example.com', 'Julia Lind', '073-7654321'),
(3, 'mitar98', '$2a$10$99GYTviptK663yjIsidXFORCHGoXpJ7KZcVQlGpi9rPIt.vPfmGwa', 'mitar@gmail.com', 'Mitar', '9213123213'),
(5, 'mitar', '$2a$10$MX3LCjCBDFyHbREVBIfSZeEQsETzkZO0FaC5ZKV9JLe64GQJAj3Pm', 'asd', 'asd', '');

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Index för tabell `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Index för tabell `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `books`
--
ALTER TABLE `books`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT för tabell `loans`
--
ALTER TABLE `loans`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT för tabell `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT för tabell `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restriktioner för dumpade tabeller
--

--
-- Restriktioner för tabell `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `loans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `loans_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

--
-- Restriktioner för tabell `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
