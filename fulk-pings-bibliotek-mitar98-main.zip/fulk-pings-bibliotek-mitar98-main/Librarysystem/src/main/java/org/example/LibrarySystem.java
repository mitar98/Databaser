package org.example;

import org.example.database.DatabaseConnection;
import org.example.utils.BCryptUtil;
import org.example.models.User;

import java.sql.*;
import java.util.Scanner;

public class LibrarySystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Välkommen till Biblioteket i Fulköping!");
            System.out.println("1. Registrera dig");
            System.out.println("2. Logga in");
            System.out.print("Välj ett alternativ: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                registerUser(scanner);
            } else if (choice == 2) {
                loginUser(scanner);
            } else {
                System.out.println("Ogiltigt val. Försök igen.");
            }
        }
    }

    private static void registerUser(Scanner scanner) {
        System.out.print("Ange användarnamn: ");
        String username = scanner.nextLine();
        System.out.print("Ange lösenord: ");
        String password = scanner.nextLine();
        System.out.print("Ange e-post: ");
        String email = scanner.nextLine();
        System.out.print("Ange namn: ");
        String name = scanner.nextLine();
        System.out.print("Ange telefonnummer: ");
        String phoneNumber = scanner.nextLine();

        String passwordHash = BCryptUtil.hashPassword(password);

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO users (username, password_hash, email, name, phone_number) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);
                stmt.setString(2, passwordHash);
                stmt.setString(3, email);
                stmt.setString(4, name);
                stmt.setString(5, phoneNumber);
                stmt.executeUpdate();
                System.out.println("Registrering lyckades! Logga in för att fortsätta.");
            }
        } catch (SQLException e) {
            System.out.println("Ett fel uppstod: " + e.getMessage());
        }
    }

    private static void loginUser(Scanner scanner) {
        System.out.print("Ange användarnamn: ");
        String username = scanner.nextLine();
        System.out.print("Ange lösenord: ");
        String password = scanner.nextLine();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT id, password_hash FROM users WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    int userId = rs.getInt("id");
                    String passwordHash = rs.getString("password_hash");

                    if (BCryptUtil.checkPassword(password, passwordHash)) {
                        System.out.println("Inloggning lyckades!");
                        userMenu(scanner, userId);
                    } else {
                        System.out.println("Felaktigt lösenord.");
                    }
                } else {
                    System.out.println("Användaren hittades inte.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Ett fel uppstod: " + e.getMessage());
        }
    }

    private static void userMenu(Scanner scanner, int userId) {
        while (true) {
            System.out.println("\\nVälj ett alternativ:");
            System.out.println("1. Se bibliotekets sortiment");
            System.out.println("2. Sök efter böcker,tidskriftermi och medier");
            System.out.println("3. Låna");
            System.out.println("4. Returnera");
            System.out.println("5. Se lånestatus");
            System.out.println("6. Reservera böcker");
            System.out.println("7. Ändra inloggningsuppgifter");
            System.out.println("8. Logga ut");
            System.out.print("Val: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> viewLibraryCatalog();
                case 2 -> searchBooks(scanner);
                case 3 -> borrowBook(scanner, userId);
                case 4 -> returnBook(scanner, userId);
                case 5 -> viewLoanStatus(userId);
                case 6 -> reserveBook(scanner, userId);
                case 7 -> updateUserInfo(scanner, userId);
                case 8 -> {
                    System.out.println("Loggar ut...");
                    return;
                }
                default -> System.out.println("Ogiltigt val. Försök igen.");
            }
        }
    }

    private static void viewLibraryCatalog() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT id, title, author, material_type, is_borrowed FROM books";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                ResultSet rs = stmt.executeQuery();

                System.out.println("\\nBibliotekets Sortimentslista:");
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String title = rs.getString("title");
                    String author = rs.getString("author");
                    String materialType = rs.getString("material_type");
                    boolean isBorrowed = rs.getBoolean("is_borrowed");

                    System.out.println("ID: " + id + " | Titel: " + title +
                            " | Författare: " + author +
                            " | Typ: " + materialType +
                            " | Utlånad: " + (isBorrowed ? "Ja" : "Nej"));
                }
            }
        } catch (SQLException e) {
            System.out.println("Fel vid hämtning av bibliotekets sortiment: " + e.getMessage());
        }
    }

    private static void searchBooks(Scanner scanner) {
        System.out.print("Ange sökterm (titel eller författare): ");
        String searchTerm = scanner.nextLine();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = """
                SELECT id, title, author, material_type, is_borrowed
                FROM books
                WHERE title LIKE ? OR author LIKE ?
                ORDER BY title
                """;
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, "%" + searchTerm + "%");
                stmt.setString(2, "%" + searchTerm + "%");
                ResultSet rs = stmt.executeQuery();

                System.out.println("Sökresultat:");
                while (rs.next()) {
                    String status = rs.getBoolean("is_borrowed") ? "Utlånad" : "Tillgänglig";
                    String materialType = rs.getString("material_type");
                    System.out.println("ID: " + rs.getInt("id") + " | Titel: " + rs.getString("title") +
                            " | Författare: " + rs.getString("author") +
                            " | Typ: " + materialType +
                            " | Status: " + status);
                }
            }
        } catch (SQLException e) {
            System.out.println("Fel vid sökning efter böcker: " + e.getMessage());
        }
    }

    private static void borrowBook(Scanner scanner, int userId) {
        System.out.print("Ange ID på boken/tidskriften/mediet du vill låna: ");
        int bookId = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String checkBookQuery = "SELECT is_borrowed, material_type FROM books WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(checkBookQuery)) {
                stmt.setInt(1, bookId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    boolean isBorrowed = rs.getBoolean("is_borrowed");
                    String materialType = rs.getString("material_type");

                    if (isBorrowed) {
                        System.out.println("Den valda boken/tidskriften/mediet är redan utlånad.");
                        return;
                    }


                    int loanPeriod = materialType.equals("book") ? 30 : 10;  // 30 dagar för böcker, 10 dagar för tidskrifter och media
                    Date returnDate = new Date(System.currentTimeMillis() + (loanPeriod * 24L * 60 * 60 * 1000)); // Lägg till låneperioden i millisekunder


                    String updateBookQuery = "UPDATE books SET is_borrowed = TRUE WHERE id = ?";
                    try (PreparedStatement stmtUpdate = conn.prepareStatement(updateBookQuery)) {
                        stmtUpdate.setInt(1, bookId);
                        stmtUpdate.executeUpdate();
                    }


                    String borrowBookQuery = """
                        INSERT INTO loans (user_id, book_id, borrow_date, return_date)
                        VALUES (?, ?, NOW(), ?)
                        """;
                    try (PreparedStatement stmtInsert = conn.prepareStatement(borrowBookQuery)) {
                        stmtInsert.setInt(1, userId);
                        stmtInsert.setInt(2, bookId);
                        stmtInsert.setDate(3, returnDate);
                        stmtInsert.executeUpdate();
                    }

                    System.out.println("Den valda boken/tidskriften/mediet har lånats ut! Låneperioden är " + loanPeriod + " dagar.");
                } else {
                    System.out.println("Boken/tidskriften/mediet finns inte.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Ett fel uppstod: " + e.getMessage());
        }
    }

    private static void returnBook(Scanner scanner, int userId) {
        System.out.print("Ange ID på boken du vill returnera: ");
        int bookId = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String checkLoanQuery = """
            SELECT l.id, l.return_date, b.is_borrowed FROM loans l
            JOIN books b ON l.book_id = b.id
            WHERE l.user_id = ? AND l.book_id = ?
            """;
            try (PreparedStatement stmt = conn.prepareStatement(checkLoanQuery)) {
                stmt.setInt(1, userId);
                stmt.setInt(2, bookId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    Date returnDate = rs.getDate("return_date");
                    boolean isBorrowed = rs.getBoolean("is_borrowed");

                    if (returnDate == null && isBorrowed) {
                        String returnBookQuery = "UPDATE loans SET return_date = CURRENT_TIMESTAMP WHERE id = ?";
                        try (PreparedStatement updateStmt = conn.prepareStatement(returnBookQuery)) {
                            updateStmt.setInt(1, rs.getInt("id"));
                            updateStmt.executeUpdate();
                        }

                        String updateBookQuery = "UPDATE books SET is_borrowed = FALSE WHERE id = ?";
                        try (PreparedStatement stmtUpdate = conn.prepareStatement(updateBookQuery)) {
                            stmtUpdate.setInt(1, bookId);
                            stmtUpdate.executeUpdate();
                        }

                        System.out.println("Boken har återlämnats.");
                    } else {
                        System.out.println("Boken har redan återlämnats den: " + returnDate);
                    }
                } else {
                    System.out.println("Du har inte lånat denna bok eller boken finns inte i systemet.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Ett fel uppstod: " + e.getMessage());
        }
    }

    private static void viewLoanStatus(int userId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String currentLoansQuery = """
                SELECT b.id AS book_id, b.title, b.author, b.material_type, l.borrow_date
                FROM books b
                JOIN loans l ON b.id = l.book_id
                WHERE l.user_id = ? AND l.return_date IS NULL
                """;
            try (PreparedStatement stmt = conn.prepareStatement(currentLoansQuery)) {
                stmt.setInt(1, userId);
                ResultSet rs = stmt.executeQuery();

                System.out.println("Nuvarande utlånade böcker:");
                while (rs.next()) {
                    String materialType = rs.getString("material_type");
                    System.out.println("ID: " + rs.getInt("book_id") + " | Titel: " + rs.getString("title") +
                            " | Författare: " + rs.getString("author") +
                            " | Typ: " + materialType +
                            " | Utlånad sedan: " + rs.getDate("borrow_date"));
                }
            }

            String loanHistoryQuery = """
                SELECT b.id AS book_id, b.title, b.author, b.material_type, l.borrow_date, l.return_date
                FROM books b
                JOIN loans l ON b.id = l.book_id
                WHERE l.user_id = ? AND l.return_date IS NOT NULL
                ORDER BY l.borrow_date DESC
                """;
            try (PreparedStatement stmt = conn.prepareStatement(loanHistoryQuery)) {
                stmt.setInt(1, userId);
                ResultSet rs = stmt.executeQuery();

                System.out.println("\nTidigare utlånade böcker:");
                while (rs.next()) {
                    String materialType = rs.getString("material_type");
                    System.out.println("ID: " + rs.getInt("book_id") + " | Titel: " + rs.getString("title") +
                            " | Författare: " + rs.getString("author") +
                            " | Typ: " + materialType +
                            " | Utlånad: " + rs.getDate("borrow_date") +
                            " | Återlämnad: " + rs.getDate("return_date"));
                }
            }
        } catch (SQLException e) {
            System.out.println("Fel vid visning av lånestatus: " + e.getMessage());
        }
    }

    private static void reserveBook(Scanner scanner, int userId) {
        System.out.print("Ange ID på boken du vill reservera: ");
        int bookId = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String reserveQuery = "INSERT INTO reservations (user_id, book_id, reservation_date) VALUES (?, ?, NOW())";
            try (PreparedStatement stmt = conn.prepareStatement(reserveQuery)) {
                stmt.setInt(1, userId);
                stmt.setInt(2, bookId);
                stmt.executeUpdate();
                System.out.println("Boken har reserverats.");
            }
        } catch (SQLException e) {
            System.out.println("Ett fel uppstod: " + e.getMessage());
        }
    }

    private static void updateUserInfo(Scanner scanner, int userId) {
        System.out.println("\nVad vill du ändra?");
        System.out.println("1. E-post");
        System.out.println("2. Namn");
        System.out.println("3. Telefonnummer");
        System.out.println("4. Lösenord");
        System.out.print("Val: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = null;
            switch (choice) {
                case 1 -> {
                    System.out.print("Ange ny e-post: ");
                    String newEmail = scanner.nextLine();
                    query = "UPDATE users SET email = ? WHERE id = ?";
                    executeUpdate(conn, query, newEmail, userId);
                    System.out.println("E-post uppdaterad.");
                }
                case 2 -> {
                    System.out.print("Ange nytt namn: ");
                    String newName = scanner.nextLine();
                    query = "UPDATE users SET name = ? WHERE id = ?";
                    executeUpdate(conn, query, newName, userId);
                    System.out.println("Namn uppdaterat.");
                }
                case 3 -> {
                    System.out.print("Ange nytt telefonnummer: ");
                    String newPhone = scanner.nextLine();
                    query = "UPDATE users SET phone_number = ? WHERE id = ?";
                    executeUpdate(conn, query, newPhone, userId);
                    System.out.println("Telefonnummer uppdaterat.");
                }
                case 4 -> {
                    System.out.print("Ange nytt lösenord: ");
                    String newPassword = scanner.nextLine();
                    String passwordHash = BCryptUtil.hashPassword(newPassword);
                    query = "UPDATE users SET password_hash = ? WHERE id = ?";
                    executeUpdate(conn, query, passwordHash, userId);
                    System.out.println("Lösenord uppdaterat.");
                }
                default -> System.out.println("Ogiltigt val.");
            }
        } catch (SQLException e) {
            System.out.println("Ett fel uppstod: " + e.getMessage());
        }
    }

    private static void executeUpdate(Connection conn, String query, String newValue, int userId) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, newValue);
            stmt.setInt(2, userId);
            stmt.executeUpdate();
        }
    }
}