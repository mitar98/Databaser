package org.example.models;

import java.util.Date;

public class Loan {
    private int id;
    private int userId;
    private int bookId;
    private Date loanDate;
    private Date dueDate;
    private Date returnDate;

    public Loan(int id, int userId, int bookId, Date loanDate, Date dueDate, Date returnDate) {
        this.id = id;
        this.userId = userId;
        this.bookId = bookId;
        this.loanDate = loanDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public int getBookId() {
        return bookId;
    }

    public Date getLoanDate() {
        return loanDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }
}