package org.example.models;

import org.example.utils.BCryptUtil;

public class User {
    private int id;
    private String username;
    private String passwordHash;
    private String email;
    private String name;
    private String phoneNumber;

    public User(String username, String password, String email, String name, String phoneNumber) {
        this.username = username;
        this.passwordHash = BCryptUtil.hashPassword(password);
        this.email = email;
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
}